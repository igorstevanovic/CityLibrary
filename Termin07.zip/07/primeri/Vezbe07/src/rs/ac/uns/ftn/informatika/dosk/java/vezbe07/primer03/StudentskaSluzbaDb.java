package rs.ac.uns.ftn.informatika.dosk.java.vezbe07.primer03;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class StudentskaSluzbaDb {

	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		try {
			// ucitavanje MySQL drajvera
			Class.forName("com.mysql.jdbc.Driver");		
			// Konekcija na bazu
			Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/studentskasluzba", "root", "rootroot");
			
			//prikaz menija
			String odluka = "";
			while (!odluka.equals("x")) {
				ispisiMenu();
				System.out.print("opcija:");
				odluka = scanner.nextLine();
				switch (odluka) {				
					case "1":
						prikaziSveStudente(conn);
						break;
					case "2":
						unosStudenta(conn);
						break;
					case "x":
						System.out.println("Izlaz");
						break;
					default:
						System.out.println("Nepostojeca komanda");
						break;
				}
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// ispis teksta osnovnih opcija
	private static void ispisiMenu() {
		System.out.println("Studentska Sluzba - Meni:");
		System.out.println("\t1 - Spisak studenata");
		System.out.println("\t2 - Unos studenta");
		System.out.println("\tx - IZLAZ IZ PROGRAMA");
	}
	
	private static void prikaziSveStudente(Connection conn) {
		List<Student> studenti = new ArrayList<Student>(); //lista studenata u memoriji
		try {
			String query = "SELECT student_id, indeks, " +
					"ime, prezime FROM studenti";
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery(query); //preuzimamo studente iz baze
			while (rset.next()) { 
				int id = rset.getInt(1);
				String indeks = rset.getString(2);
				String ime = rset.getString(3);
				String prezime = rset.getString(4);		
				//kreiramo objekat u memoriji na osnovu preuzetog sloga iz baze
				Student student = new Student(id, indeks, ime, prezime);
				studenti.add(student); //dodamo objekat Student u listu svih studenata
			}
			rset.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// sada imamo napunjenu listu studenata u memoriji 
		// Prolazimo kroz listu i ispisujemo podatke o svakom studentu
		for (Student s: studenti) {
			System.out.println(s);
		}
	}
	
	private static void unosStudenta(Connection conn) {
		System.out.print("Unesi indeks:");
		String stIndex = scanner.nextLine();
		System.out.print("Unesi ime:");
		String stIme = scanner.nextLine();
		System.out.print("Unesi prezime:");
		String stPrezime = scanner.nextLine();
		//kreiramo objekat student u memoriji
		Student student = new Student(0, stIndex, stIme, stPrezime);
		//sadrzaj objekta ubacimo u bazu podataka
		try {
			String insert = "INSERT INTO studenti " +
					"(indeks, ime, prezime) values " +
					"(?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(
					insert);
			pstmt.setString(1, student.getIndeks());
			pstmt.setString(2, student.getIme());
			pstmt.setString(3, student.getPrezime());
			if (pstmt.executeUpdate() == 1) {
				System.out.println("Student je uspesno dodan.");
			} else {
				System.out.println("Greska pri dodavanju studenta.");
			}
			pstmt.close();
		} catch (SQLException e) {
			System.out.println("Greska pri dodavanju studenta.");
		}
	}
}
