package rs.ac.uns.ftn.informatika.dosk.java.vezbe07.primer02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class Demo2_mysql {

	public static void main(String args[]) {
		try {
			// ucitavanje MySQL drajvera
			Class.forName("com.mysql.jdbc.Driver");

			// konekcija
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/studentskasluzba", 
					"root", "rootroot");

			// Dodavanje novog grada
			Statement stmt = conn.createStatement();
			String query = "insert into grad (ptt, naziv) " +
					"values (26300, 'Vrsac')";
			stmt.executeUpdate(query);
			
			//dodavanje novog grada. Korisnik unosi podatke
			Scanner scanner = new Scanner(System.in);
			System.out.println("Unesite ptt broj:");
			String ptt  = scanner.nextLine();
			System.out.println("Unesite naziv:");
			String naziv  = scanner.nextLine();

			query = "insert into grad (ptt, naziv) " +
					"values (" + ptt + ", '" + naziv + "')";
			stmt.executeUpdate(query);
			
			/*
			 * Kod prethodnog nacina moguc je sql-injection
			 * Zato se uvek koristi preparedStatement kad god se u upitu
			 * nalaze i podaci uneseni od strane korisnika
			 * */ 
			System.out.println("============== Naredni grad ===========");
			System.out.println("Unesite ptt broj:");
			ptt  = scanner.nextLine();
			System.out.println("Unesite naziv:");
			naziv  = scanner.nextLine();
		
			//pripremljeni upit sadrzi parametre koji se naknadno postave
			PreparedStatement pstmt = conn.prepareStatement(
					"insert into grad (ptt, naziv) values " +
					"(?, ?)");
			pstmt.setInt(1, Integer.valueOf(ptt));
			pstmt.setString(2, naziv);
			pstmt.executeUpdate();

			stmt.close();
			conn.close();
			scanner.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
