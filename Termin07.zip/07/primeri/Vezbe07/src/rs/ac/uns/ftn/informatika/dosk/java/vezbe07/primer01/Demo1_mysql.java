package rs.ac.uns.ftn.informatika.dosk.java.vezbe07.primer01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Demo1_mysql {

	public static void main(String args[]) {
		try {
			// ucitavanje MySQL drajvera
			Class.forName("com.mysql.jdbc.Driver");

			// konekcija
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/studentskasluzba", 
					"root", "rootroot");

			// Slanje upita
			String query = "SELECT ptt, naziv FROM grad";
			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery(query);

			// Citanje rezultata upita
			while (rset.next()) {
				System.out.println(rset.getInt(1) + 
						" " + rset.getString(2));
			}

			// zatvaranje veze
			rset.close();
			stmt.close();
			conn.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
